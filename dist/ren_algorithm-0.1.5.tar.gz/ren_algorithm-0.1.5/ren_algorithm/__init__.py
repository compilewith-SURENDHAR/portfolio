from .XGBoost.xgboost_regression import CustomXGBoostRegressor

from .SVM.svm import SVM

from .randomforest.random_forest import RandomForest

from .logisticregression.logistic_regression import LogisticRegression

from .Linearregression.linear_regression import LinearRegression

from .KNNmodel.knn import KNN

from .decisiontreeclassification.decision_tree import DecisionTree